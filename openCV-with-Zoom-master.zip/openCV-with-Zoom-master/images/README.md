For Image Capture
